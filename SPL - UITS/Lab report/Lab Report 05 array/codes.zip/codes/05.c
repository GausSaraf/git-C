#include<stdio.h>

int main()
{
    int N, value,count =0;
    printf("Size of Array: ");
    scanf("%d",&N);
    float a[N];
    printf("Input %d elements of Array: \n",N);
    for(int i =1; i<=N; i++)
    {
        scanf("%f",&a[i]);
    }
    printf("Value to find?\nInput: ");
    scanf("%d",&value);
    printf("\nResult:\n\n");
    for(int i = 1; i<=N; i++)
    {
        if(a[i]==value)
        {
            printf("Found %d in Position %d\n", value, i);
            count++;
        }
    }
    if(count==0)
    {
        printf("value not found.\n");
    }

    return 0;
}
