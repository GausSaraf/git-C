#include<stdio.h>

int main()
{
    int N, max = 0, min = 0;
    printf("Size of Array: ");
    scanf("%d",&N);
    float a[N];
    printf("Input %d elements of Array: \n",N);
    for(int i =1; i<=N; i++)
    {
        scanf("%f",&a[i]);
    }

    max = a[1], min = a[1];
    for(int i =2; i<=N; i++)
    {
        if(a[i]>max)
        {
            max = a[i];
        }
        if(a[i]<min)
        {
            min = a[i];
        }
    }
    printf("Max is %d\nMin is %d\n",max,min);

    return 0;
}
