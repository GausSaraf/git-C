#include<stdio.h>

int main()
{
    int N,count = 0;
    printf("Size of Array: ");
    scanf("%d",&N);
    int a[N];
    printf("Input %d elements of Array: \n",N);
    for(int i =1; i<=N; i++)
    {
        scanf("%d",&a[i]);
        if(a[i]<0)
        {
            count++;
        }
    }
    if(count==0)
    {
        printf("no negative elements found");
    }
    else
    {
        printf("\nThe negative elements are:\n");
        for(int i = 1; i<=N; i++)
        {
            if(a[i]<0)
            {
                printf("%d\n",a[i]);
            }

        }
    }

    return 0;
}
