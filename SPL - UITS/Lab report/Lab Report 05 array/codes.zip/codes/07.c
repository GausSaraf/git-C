#include<stdio.h>

int main()
{
    int N, i,value,position;
    printf("Size of Array: ");
    scanf("%d",&N);
    int a[N];
    printf("\ninsert value?\nInput: ");
    scanf("%d",&value);
    printf("\nto position?\nInput: ");
    scanf("%d",&position);
    if(position<=N)
    {
        i = position;
        a[i] = value;
        printf("%d was inserted to array element a[%d]\n\nResult: a[%d] = %d\n",value, position, position, a[i]);
    }
    else
    {
        printf("[ Invalid position or array size ]\n");
    }


    return 0;
}
