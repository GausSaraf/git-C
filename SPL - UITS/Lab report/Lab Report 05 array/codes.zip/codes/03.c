#include<stdio.h>

int main()
{
    int N;
    float sum = 0,avg = 0;
    printf("Size of Array: ");
    scanf("%d",&N);
    float a[N];
    printf("Input %d elements of Array: \n",N);
    for(int i =1; i<=N; i++)
    {
        scanf("%f",&a[i]);
        sum = sum + a[i];
    }
    avg = sum/N;
    printf("Sum is %.3f\nAverage is %.3f\n",sum,avg);

    return 0;
}
