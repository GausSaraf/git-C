#include<stdio.h>

int main()
{
    int N, i,position;
    printf("Size of Array: ");
    scanf("%d",&N);
    int a[N];
   printf("Input %d elements/values of Array: \n",N);
    for(int i =1; i<=N; i++)
    {
        scanf("%d",&a[i]);
    }
    printf("\nDelete value from position?\nInput: ");
    scanf("%d",&position);
    a[position]= 0;
    printf("modified array elements:\n");
    for(int i =1; i<=N; i++)
    {
        printf("%d\n",a[i]);
    }

    return 0;
}
