#include<stdio.h>

int main()
{
    int N, value,count =0;
    printf("Size of Array: ");
    scanf("%d",&N);
    float a[N],b[N];
    printf("Input %d elements of Array: \n",N);
    for(int i =1; i<=N; i++)
    {
        scanf("%f",&a[i]);
    }
    printf("\nCopying elements of the 1st array:\n");
    for(int i =1; i<=N; i++)
    {
        printf("%.1f (copied to element b[%d])\n",a[i],i);
        b[i]=a[i];
    }
    printf("\nElements of 2nd array:\n");
    for(int i =1; i<=N; i++)
    {
        printf("b[%d] = %.1f\n",i,b[i]);
    }


    return 0;
}
