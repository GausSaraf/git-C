//Write a C program to enter the length and breadth of a rectangle and find its area.

#include <stdio.h>

int main()
{
    int a,b;
    scanf("%d %d", &a, &b);
    printf("Area of rectangle is = %d", a*b);
    
    return 0;
}