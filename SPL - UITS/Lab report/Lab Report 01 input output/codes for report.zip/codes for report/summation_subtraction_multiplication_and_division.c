//Write a C program to take input of three numbers and find their summation, subtraction, multiplication, and division.

#include <stdio.h>

int main()
{
    float a,b,c;
    scanf("%f %f %f", &a,&b,&c);
    printf("summation = %.1f\nsubstraction = %.1f\nmultiplication = %.1f\ndivision = %.4f\n",((a+b)+c),((a-b)-c),((a*b)*c),((a/b)/c));
    return 0;
}