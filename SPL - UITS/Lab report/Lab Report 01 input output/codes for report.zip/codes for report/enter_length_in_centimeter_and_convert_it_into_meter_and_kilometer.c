//Write a C program to enter length in centimeter and convert it into meter and kilometer

#include <stdio.h>

int main()
{
    float a;
    printf("enter length in centimeter: \n");
    scanf("%f", &a);
    printf("in meter scale it is = %f\n", a/100); 
    printf("in kilometer scale it is = %f\n", (a/100)/1000);


    return 0;
}