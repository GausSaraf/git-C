//Write a C program to enter temperature in Celsius and convert it into Fahrenheit

#include <stdio.h>

int main()
{
    float C;
    scanf("%f", &C);
    printf("temperature in Fahrenheit is = %.2f", (C*9/5)+32);


    return 0;
}