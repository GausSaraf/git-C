//Write a C program to find the area of a circle by taking user input

#include <stdio.h>

int main()
{
    float r, pi;
    pi = 3.14;
    scanf("%f", &r);
    printf("Area of circle is = %.2f", pi * r * r);

    return 0;
}