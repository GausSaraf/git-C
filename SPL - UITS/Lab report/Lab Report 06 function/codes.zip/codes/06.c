#include<stdio.h>
#include<math.h>

int Pow(int x, int y)
{
    int mul = 1;
    for(int i = 1; i<=y;i++)
    {
        mul = mul*x;
    }
    return mul;
}

int main()
{
    int x,y,result;
    printf("Input base value: \n");
    scanf("%d", &x);
    printf("Input power value: \n");
    scanf("%d", &y);

    result = Pow(x,y);
    printf("\npower %d of base %d is %d\n",y,x,result);


    return 0;
}
