#include<stdio.h>

float dia(float r)
{
    return r*2;
}
float circum(float r)
{
    float pi = 3.1416;
    return 2*pi*r;
}
float A(float r)
{
    float pi = 3.1416;
    return pi*r*r;
}

int main()
{
    float r,diameter,circumference,area;
    printf("Input radius of circle: ");
    scanf("%f", &r);
    diameter = dia(r);
    circumference = circum(r);
    area = A(r);
    printf("diameter is %.1f\ncircumference is %.1f\narea is %.1f\n", diameter,circumference,area);

    return 0;
}
