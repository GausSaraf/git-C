#include<stdio.h>

int main()
{
    int n,result;
    printf("Find factorial of: \n");
    scanf("%d", &n);
   factorial(n);


    return 0;
}

void factorial(int n)
{
    int mul = 1;
    for(int i = 1; i<=n;i++)
    {
        mul = mul*i;
    }
    printf("\nFactorial of %d is %d\n",n,mul);
}
