#include<stdio.h>

int cube(int a)
{
    return a*a*a;
}

int main()
{
    int a,result;
    printf("Input number: ");
    scanf("%d", &a);
    result = cube(a);
    printf("cube is %d", result);

    return 0;
}
