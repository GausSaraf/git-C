#include<stdio.h>

void print_num(int n)
{
 for(int i = 1; i<=n;i++)
 {
     printf("%d ",i);
 }
}

int main()
{
    int n,result;
    printf("Input end range: \n");
    scanf("%d", &n);
    print_num(n);


    return 0;
}
