#include<stdio.h>

even_or_odd(int n, int result)
{
  if(n%2==0)
  {
      result = 1;
  }

  return result;
}

int main()
{
    int n,result = 0;
    printf("Input a number: \n");
    scanf("%d", &n);
   result = even_or_odd(n,result);
   if(result)
   {
       printf("\nnumber is Even\n");
   }
   else
   {
       printf("\nnumber is Odd\n");
   }

    return 0;
}
