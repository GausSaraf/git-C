#include<stdio.h>

void perfect(int n1, int n2)
{
    printf("\nPerfect numbers within the given interval:\n");
    for(n1; n1<n2; n1++)
    {
        int sum = 0;
        for(int i=1; i<n1; i++)
        {
            if(n1%i==0)
            {
                sum = sum+i;
            }
        }
        if(sum==n1)
        {
            printf("%d ",n1);
        }
    }

}

int main()
{

    int n1,n2;
    printf("Input start of interval: \n");
    scanf("%d", &n1);
    printf("Input end of interval: \n");
    scanf("%d", &n2);

    perfect(n1,n2);

    printf("\n");
    return 0;
}
