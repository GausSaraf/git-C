#include<stdio.h>

void even(int n1, int n2)
{
    int sum = 0;
    printf("\nResult:\n");
    for(n1;n1<=n2;n1++)
    {
        if(n1%2==0)
        {
            sum = sum +n1;
        }
    }
    printf("Sum of Even Numbers = %d\n", sum);
}
void odd(int n1, int n2)
{
    int sum = 0;
    printf("\nResult:\n");
    for(n1;n1<=n2;n1++)
    {
        if(n1%2!=0)
        {
            sum = sum +n1;
        }
    }
    printf("Sum of Odd Numbers = %d\n", sum);
}

int main()
{
    int n1,n2,what;
    printf("Input start range: \n");
    scanf("%d", &n1);
    printf("Input end range: \n");
    scanf("%d", &n2);
printf("Print sum of Even (0) / Odd (1)?\n");
scanf("%d",&what);
if(what==0)
{
    even(n1,n2);
}
else if(what==1)
{
    odd(n1,n2);
}
else
{
    printf("INVALID");
}

    return 0;
}
