#include<stdio.h>

max(int n1, int n2)
{
  int tmp = n1; //say n1 is max
  if(n2>tmp)//if n2 is bigger then reassign
  {
      tmp = n2;
  }
  return tmp;
}
min(int n1, int n2)
{
    int tmp = n1; //say n1 is max
  if(n2<tmp)//if n2 is less then reassign
  {
      tmp = n2;
  }
  return tmp;
}

int main()
{
    int n1,n2,maximum,minimum;
    printf("Input 2 numbers: \n");
    scanf("%d%d", &n1,&n2);
    maximum = max(n1,n2);
    minimum = min(n1,n2);
    printf("Max is %d\nMin is %d\n",maximum,minimum);

    return 0;
}
