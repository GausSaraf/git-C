// Write a C program to take input of a number and the number is positive, negative, or zero and the number is odd or even. Bing search: Is zero even number? --> Zero is an even number in mathematics, as it is an integer multiple of 21. This can be easily verified based on the definition of "even".

#include <stdio.h>

int main()
{
    int a;
    scanf("%d", &a);

    if (a == 0)
    {
        printf("The number is Zero");
    }
    else if (a > 0)
    {
        printf("The number is Positive");
    }
    else
    {
        printf("The number is Negative");
    }

    if (a % 2 == 0)
    {
        printf(" and it is Even\n");
    }
    else
    {
        printf(" and it is Odd\n");
    }
    return 0;
}
