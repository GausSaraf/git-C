//Write a C program to input angles of a triangle and check whether triangle is valid or not

#include <stdio.h>


int main()
{
    float a,b,c; //can take int as well
    scanf("%f %f %f", &a,&b,&c);
    if(a+b+c==180 && a!=0 && b!=0 && c!=0 )
    { 
        {printf("Triangle is valid");}
    }
    else
    {
         printf("Triangle is NOT valid");
    }

    return 0;


}

