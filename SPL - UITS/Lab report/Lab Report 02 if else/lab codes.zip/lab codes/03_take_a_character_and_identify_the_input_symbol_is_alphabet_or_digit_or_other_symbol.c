// Write a C program to take input of a character and identify the input symbol is alphabet or digit or other symbol

#include <stdio.h>

int main()
{
    char ch;
    scanf("%c", &ch);

    if (ch >= 'A' && ch <= 'Z' || ch >= 'a' && ch <= 'z')
    {
        printf("the character is an Alphabet");
    }
    else if (ch >= '0' && ch <= '9')
    {
        printf("the character is a Digit");
    }

    /*else if (ch >= 32 && ch <= 47 || ch >= 58 && ch <= 64 || ch >= 91 && ch <= 96 || ch >= 123 && ch <= 126)
        {
            printf("the character is a Special Character");
        }
    */
    else
    {
        printf("the character is other symbol");
    }

    return 0;
}
