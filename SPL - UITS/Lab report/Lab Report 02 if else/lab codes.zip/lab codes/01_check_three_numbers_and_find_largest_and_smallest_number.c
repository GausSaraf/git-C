// Write a C program to take input of three numbers and find the largest and smallest number among them

#include <stdio.h>

int main()
{
    int a, b, c;    // the 3 numbers
    int tmp1, tmp2; // temporary variable

    scanf("%d%d%d", &a, &b, &c);

    if (a > b)
    {
        tmp1 = a, tmp2 = b;
    }
    else
    {
        tmp1 = b, tmp2 = a;
    }
    if (tmp1 > c)
    {
        printf("Largest is = %d\nSmallest is = %d\n", tmp1, c);
    }
    else
    {
        printf("Largest is = %d\nSmallest is = %d\n", c, tmp2);
    }

    return 0;
}