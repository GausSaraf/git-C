// Write a C program to take input of a character and identify the character is vowel or consonant.

#include <stdio.h>

int main()
{
    char ch;
    scanf("%c", &ch);
    if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
    {
        printf("The character is a vowel");
    }
    else if (ch >= 'A' && ch <= 'Z' || ch >= 'a' && ch <= 'z')
    {
        printf("The character is a consonent");
    }
    else
    {
        printf("Wrong input! The character is not an alphabet");
    }

    return 0;
}
