/*
Write a C program to input marks of five subjects Physics, Chemistry, Biology, Mathematics and Computer. Calculate percentage and grade according to following:

Percentage >= 90%: Grade A
Percentage >= 80%: Grade B
Percentage >= 70%: Grade C
Percentage >= 60%: Grade D
Percentage >= 40%: Grade E
Percentage < 40%: Grade F
*/

#include <stdio.h>

int main()
{
    int a,b,c,d,e;
    int avg;
    printf("Input marks out of 100 for,\nPhysics: ");
    scanf("%d",&a);
    printf("Chemistry: ");
    scanf("%d",&b);
    printf("Biology: ");
    scanf("%d",&c);
    printf("Mathematics: ");
    scanf("%d",&d);
    printf("Computer: ");
    scanf("%d",&e);

avg = (a+b+c+d+e)/5;

printf("Your marks average is %d percent\n", avg);

if(avg >= 90){printf("You got Grade A");}
else if(avg >= 80){printf("You got Grade B");}
else if(avg >= 70){printf("You got Grade C");}
else if(avg >= 60){printf("You got Grade D");}
else if(avg >= 40){printf("You got Grade E");}
else if(avg < 40){printf("You got Grade F");}

    return 0;
}

