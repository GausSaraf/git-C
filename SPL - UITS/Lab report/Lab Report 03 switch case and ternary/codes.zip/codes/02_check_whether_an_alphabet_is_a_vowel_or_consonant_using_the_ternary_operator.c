// Write a C program to check whether an alphabet is a vowel or consonant using the ternary operator
#include <stdio.h>
int main()
{
    char ch;
    printf("Enter a character: ");
    scanf("%c", &ch);
    (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') ? printf("\n\nIs's a Vowel\n\n") : printf("\n\nIt's a Consonant\n\n");
    return 0;
}
