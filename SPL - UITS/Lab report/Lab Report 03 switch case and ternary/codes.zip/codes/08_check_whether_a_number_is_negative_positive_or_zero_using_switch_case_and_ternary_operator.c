// Write a C program to check whether a number is negative, positive or zero using switch case and ternary operator
#include <stdio.h>
int main()
{
    int num;
    printf("Enter number to find +ve/-ve/0: \n\n");
    scanf("%d", &num);
    printf("\n\n( using Switch Case )\n\n");
    switch (num == 0)
    {
    case 1:
        printf("Zero");
        break;
    case 0:
        switch (num > 0)
        {

        case 1:
            printf("Positive");
            break;
        default:
            printf("Negative");
        }
    }
    printf("\n\n( using Ternary Operator )\n\n");
    (num == 0) ? printf("Zero") : ((num > 0) ? printf("Positive") : printf("Negative"));
    printf("\n\n");

    return 0;
}
