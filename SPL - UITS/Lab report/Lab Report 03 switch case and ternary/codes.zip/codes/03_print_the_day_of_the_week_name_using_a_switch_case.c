// Write a C program to print the day of the week name using a switch case
#include <stdio.h>
int main()
{
    int day;
    printf("Enter day number(1-7): ");
    scanf("%d", &day);
    switch (day)
    {
    case 1:
        printf("Sunday"); //international weekend
        break;
    case 2:
        printf("Monday");
        break;
    case 3:
        printf("Tuesday");
        break;
    case 4:
        printf("Wednesday");
        break;
    case 5:
        printf("Thursday");
        break;
    case 6:
        printf("Friday");
        break;
    case 7:
        printf("Saturday");
        break;
    default:
        printf("NULL");
    }
    return 0;
}
