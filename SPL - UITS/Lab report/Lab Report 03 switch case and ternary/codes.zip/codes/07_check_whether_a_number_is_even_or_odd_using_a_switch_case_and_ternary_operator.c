// Write a C program to check whether a number is even or odd using a switch case and ternary operator
#include <stdio.h>
int main()
{
    int num;
    printf("Input a number for checking Even or Odd: ");
    scanf("%d", &num);
    printf("\n\n( using Switch Case )\n\n");
    switch (num % 2 == 0)
    {
    case 1:
        printf("Even");
        break;
    default:
        printf("Odd");
    }
    printf("\n\n( using Ternary Operator )\n\n");
    (num % 2 == 0) ? printf("\nThe number is Even\n") : printf("\nThe number is Odd\n");
    printf("\n\n");
    return 0;
}
