// Write a C program to find the maximum and minimum number between two numbers using a switch case

#include <stdio.h>

int main()
{
    int num1, num2;
    printf("Enter two numbers to compare: ");
    scanf("%d %d", &num1, &num2);
    switch (num1 > num2)
    {
    case 1:
        printf("Maximum number is %d and Minimum number is %d", num1, num2);
        break;
    default:
        printf("Maximum number is %d and Minimum number is %d", num2, num1);
    }
    return 0;
}
