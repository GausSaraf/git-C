//Write a C program to print all alphabets from a to z.

#include<stdio.h>
int main()
{
    for(char i = 'a'; i <='z';i++)
    {
        printf("%c\n",i);

    }

    return 0;
}
