//Write a C program to print prime numbers between 1 to n.

#include<stdio.h>

int main()
{
    int i, n, tmp;
    scanf("%d", &n);
    printf("The prime numbers from 1 to %d are: \n",n);

    for(i = 1; i<=n; i++)
        //divide by 2 and check if it's divisible by it's lower values ????
    {
        if(i== 2 || i==3 || i ==2+3 || i == 2+2+3)
        {
            printf("%d\n",i);
        }
        else if(i!=1 && i%2!=0 && i%3!=0 && i%5!=0 && i%7!=0)
        {
            printf("%d\n",i);
        }
        else
        {
            continue;
        }

    }

    return 0;
}
