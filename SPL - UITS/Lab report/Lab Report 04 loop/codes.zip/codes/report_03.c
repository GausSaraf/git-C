//Write a C program to print sum of all even numbers between 1 to n.

#include<stdio.h>

int main()
{
    int sum =0,n;
    scanf("%d",&n);
    printf("Sum = %d", sum);
    for(int i=1; i<=n; i++)
    {
        if(i%2==0)
        {
            sum = sum + i;
            printf(" + %d ",i);

        }
        else
        {

            continue;

        }

    }
    printf("= %d", sum);

    return 0;
}

