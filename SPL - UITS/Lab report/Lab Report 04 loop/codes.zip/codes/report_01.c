//Write a C program to print all natural numbers in reverse (from n to 1)

#include<stdio.h>
int main()
{
    int n;
    printf("Give an initial number: ");
    scanf("%d", &n);
    printf("\n\n");
    for(int i=n; i>=1; i--)
    {
        printf("%d\n", i);
    }

    return 0;
}
