//Write a C program to print (multiplication?) table of any number.

#include<stdio.h>

int main()
{
    int a;
    scanf("%d", &a);

    for(int i = 1; i<=10;i++)
    {
        printf("%d * %d = %d\n",a,i,a*i);
    }

    return 0;
}

