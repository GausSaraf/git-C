//Write a c program to print the result of 5!.

#include <stdio.h>

int main()
{
    int i,sum=1;
    for(i=5;i>=1;i--)
    {
        sum=sum*i;
    }
    printf("result of 5! = %d",sum);


    return 0;
}

