//Write a C program to enter any number and calculate sum of all natural numbers between 1 to n

#include<stdio.h>

int main()
{
    int i,n,sum;
    sum=0;
    printf("enter any number: \n");
    scanf("%d", &n);
    printf("\nsum of all natural numbers between: \n");
    for(i=1; i<=n; i++)
    {
        sum= sum+i;
    }
    printf("%d",sum);
    return 0;
}
