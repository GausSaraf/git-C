//Write a c program to print all numbers from 1 to 10 without number 5.

#include <stdio.h>

int main()
{
    int i = 1;
    while(i>0 && i<=10)
    {
        i!=5? printf("%d ",i):printf("");
        i++;
    }

    return 0;
}

