//Write a c program to print the following series
//1 10
//..
//10 1

#include <stdio.h>

int main()
{

     int i = 1;
    while(i>=0 && i<=10){

        printf("%d ",i);
        i++;
        printf("%d \n",12-i);

    }
    return 0;
}

