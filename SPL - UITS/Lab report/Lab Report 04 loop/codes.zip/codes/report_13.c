//Write a c program to find out the vowel and consonant by using for loop and mark it via �v� and �c� respectively.

#include<stdio.h>

int main()
{
    char ch;
    int count1=0,count2=0;
    //scanf("%c", &ch);
    for(ch='a'; ch<='z'; ch++)
    {
        if(ch=='a'|| ch=='e' || ch=='i'|| ch=='o'|| ch=='u')
        {
            printf("V for %c\n",ch);

        }
        else
        {
            printf("C for %c\n",ch);

        }
    }

    return 0;
}


