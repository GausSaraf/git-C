#include<stdio.h>

int main()
{
    int i = 70;
    while(i>=50) //i<10
    {
        //(i%2==0)? printf("%d",i): printf("\n");
         printf("%d\n",i);
         i=i-2;
        //i--;
    }


    return 0;
}
