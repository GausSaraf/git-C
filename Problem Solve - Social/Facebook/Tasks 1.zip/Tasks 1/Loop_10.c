#include <stdio.h>
int main()
{
    int i;
    do
    {
      printf("We can do it");
    }
    while(i=0);
    return 0;
}
